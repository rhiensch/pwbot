﻿namespace Bot
{
	interface IPathFinder
	{
		Planet FindNextPlanetInPath(Planet source);
	}
}
